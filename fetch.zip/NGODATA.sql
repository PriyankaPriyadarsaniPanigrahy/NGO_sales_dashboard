-- Step 1: Create the Database
CREATE DATABASE ngosales_db;
USE ngosales_db;

-- Step 2: Create the Table
CREATE TABLE ngo_product_sales (
    Product_ID VARCHAR(10) PRIMARY KEY,
    Product_Name VARCHAR(100),
    Category VARCHAR(50),
    Unit_Cost_USD DECIMAL(10,2),
    Selling_Price_USD DECIMAL(10,2),
    Quantity_Sold INT,
    Total_Revenue_USD DECIMAL(12,2),
    Beneficiaries INT,
    Location VARCHAR(100),
    Sales_Date DATE,
    Sales_Manager VARCHAR(100),
    NGO_Branch VARCHAR(50),
    Campaign_Name VARCHAR(100),
    Donor_Name VARCHAR(100),
    Funds_Allocated_USD DECIMAL(12,2),
    Funds_Utilized_USD DECIMAL(12,2),
    Notes TEXT,
    Status VARCHAR(50),
    Product_Condition VARCHAR(50),
    Delivery_Mode VARCHAR(50)
);

-- Step 3: Insert Data (All 30 Rows)
INSERT INTO ngo_product_sales VALUES
('001', 'Eco-Friendly Bags', 'Environment', 2.00, 5.00, 1000, 5000.00, 500, 'Bhubaneswar', '2023-01-15', 'Biswa Mohanty', 'Ama Odisha', 'Green Odisha Drive', 'Kalinga EcoFund', 10000.00, 5000.00, 'High demand', 'Completed', 'New', 'Direct'),
('002', 'Reusable Water Bottles', 'Environment', 3.00, 7.00, 800, 5600.00, 400, 'Cuttack', '2023-02-10', 'Madhusmita Nayak', 'Seva Odisha', 'Clean Water Mission', 'Mahanadi Trust', 8000.00, 4500.00, 'Good response', 'Ongoing', 'New', 'Online'),
('003', 'Solar Lanterns', 'Energy', 10.00, 20.00, 500, 10000.00, 1000, 'Kendrapara', '2023-03-05', 'Prakash Das', 'Utkal Jyoti', 'Bijuli Jyoti Yojana', 'Sunlight Odisha', 15000.00, 10000.00, 'Delivered on time', 'Completed', 'Refurbished', 'Direct'),
('004', 'Sanitary Kits', 'Health', 5.00, 10.00, 1200, 12000.00, 600, 'Puri', '2023-04-20', 'Sasmita Kar', 'Swasthya Odisha', 'Health for All', 'Jagannath Seva', 20000.00, 15000.00, 'Distributed in schools', 'Ongoing', 'New', 'Direct'),
('005', 'School Kits', 'Education', 8.00, 15.00, 900, 13500.00, 450, 'Balasore', '2023-05-12', 'Rakesh Parida', 'Shiksha Odisha', 'Back to School', 'Vidya Jyoti', 12000.00, 9000.00, 'Delayed delivery', 'Ongoing', 'New', 'Online'),
('006', 'Organic Seeds', 'Agriculture', 1.50, 3.00, 2000, 6000.00, 1000, 'Sambalpur', '2023-06-18', 'Ankita Behera', 'Krushi Odisha', 'Grow Green', 'Mati Seva', 5000.00, 4000.00, 'High demand in rural areas', 'Completed', 'New', 'Direct'),
('007', 'Handmade Soaps', 'Health', 2.50, 6.00, 1500, 9000.00, 750, 'Rourkela', '2023-07-22', 'Dibya Ranjan Patnaik', 'Swastha Seva', 'Clean Hands Drive', 'Hygiene Odisha', 10000.00, 7000.00, 'Good sales', 'Ongoing', 'New', 'Online'),
('008', 'Recycled Notebooks', 'Education', 1.00, 3.00, 2500, 7500.00, 1250, 'Berhampur', '2023-08-30', 'Manaswini Sahu', 'Shiksha Seva', 'Paper for Education', 'Pustak Fund', 8000.00, 6000.00, 'Distributed in schools', 'Completed', 'Recycled', 'Direct'),
('009', 'Water Filters', 'Health', 12.00, 25.00, 600, 15000.00, 300, 'Bhadrak', '2023-09-14', 'Laxmikanta Senapati', 'Water Odisha', 'Clean Water Drive', 'WaterAid Odisha', 20000.00, 15000.00, 'Installation ongoing', 'Ongoing', 'New', 'Direct'),
('010', 'Eco-Friendly Utensils', 'Environment', 4.00, 8.00, 1000, 8000.00, 500, 'Jharsuguda', '2023-10-05', 'Mamata Mohapatra', 'Zero Waste Odisha', 'Plastic Free Odisha', 'Green Future', 12000.00, 8000.00, 'Good response', 'Ongoing', 'New', 'Online'),
('011', 'Eco-Friendly Bags', 'Environment', 2.00, 5.00, 1000, 5000.00, 500, 'Urban Area A', '2023-01-15', 'John Doe', 'Branch A', 'Green Earth Campaign', 'Green Fund', 10000.00, 5000.00, 'High demand', 'Completed', 'New', 'Direct'),
('012', 'Reusable Water Bottles', 'Environment', 3.00, 7.00, 800, 5600.00, 400, 'Rural Area B', '2023-02-10', 'Jane Smith', 'Branch B', 'Clean Water Initiative', 'Blue Ocean', 8000.00, 4500.00, 'Good response', 'Ongoing', 'New', 'Online'),
('013', 'Solar Lanterns', 'Energy', 10.00, 20.00, 500, 10000.00, 1000, 'Rural Area C', '2023-03-05', 'Alice Johnson', 'Branch C', 'Light Up Lives', 'Sun Foundation', 15000.00, 10000.00, 'Delivered on time', 'Completed', 'Refurbished', 'Direct'),
('014', 'Sanitary Kits', 'Health', 5.00, 10.00, 1200, 12000.00, 600, 'Urban Area D', '2023-04-20', 'Michael Brown', 'Branch D', 'Health for All', 'Health Aid', 20000.00, 15000.00, 'Distributed in schools', 'Ongoing', 'New', 'Direct'),
('015', 'School Kits', 'Education', 8.00, 15.00, 900, 13500.00, 450, 'Rural Area E', '2023-05-12', 'Sarah Lee', 'Branch E', 'Back to School', 'EduCare', 12000.00, 9000.00, 'Delayed delivery', 'Ongoing', 'New', 'Online'),
('016', 'Organic Seeds', 'Agriculture', 1.50, 3.00, 2000, 6000.00, 1000, 'Rural Area F', '2023-06-18', 'David Wilson', 'Branch F', 'Grow Green', 'Farm Aid', 5000.00, 4000.00, 'High demand in rural areas', 'Completed', 'New', 'Direct'),
('017', 'Handmade Soaps', 'Health', 2.50, 6.00, 1500, 9000.00, 750, 'Urban Area G', '2023-07-22', 'Emily Davis', 'Branch G', 'Clean Hands Campaign', 'Hygiene First', 10000.00, 7000.00, 'Good sales', 'Ongoing', 'New', 'Online'),
('018', 'Recycled Notebooks', 'Education', 1.00, 3.00, 2500, 7500.00, 1250, 'Rural Area H', '2023-08-30', 'Robert Taylor', 'Branch H', 'Paper for Education', 'EcoFund', 8000.00, 6000.00, 'Distributed in schools', 'Completed', 'Recycled', 'Direct'),
('019', 'Water Filters', 'Health', 12.00, 25.00, 600, 15000.00, 300, 'Rural Area I', '2023-09-14', 'Laura Martinez', 'Branch I', 'Clean Water for All', 'WaterAid', 20000.00, 15000.00, 'Installation ongoing', 'Ongoing', 'New', 'Direct'),
('020', 'Eco-Friendly Utensils', 'Environment', 4.00, 8.00, 1000, 8000.00, 500, 'Urban Area J', '2023-10-05', 'James Anderson', 'Branch J', 'Zero Waste Campaign', 'Green Future', 12000.00, 8000.00, 'Good response', 'Ongoing', 'New', 'Online'),
('021', 'Mosquito Nets', 'Health', 6.00, 12.00, 1200, 14400.00, 600, 'Rural Area K', '2023-11-10', 'Maria Garcia', 'Branch K', 'Malaria Free Zone', 'Health First', 15000.00, 12000.00, 'Distributed in villages', 'Completed', 'New', 'Direct'),
('022', 'Solar Chargers', 'Energy', 15.00, 30.00, 400, 12000.00, 200, 'Rural Area L', '2023-12-01', 'Daniel Clark', 'Branch L', 'Power for All', 'Sun Energy', 10000.00, 8000.00, 'Installation ongoing', 'Ongoing', 'Refurbished', 'Direct'),
('023', 'First Aid Kits', 'Health', 7.00, 15.00, 800, 12000.00, 400, 'Urban Area M', '2024-01-15', 'Olivia White', 'Branch M', 'Health First', 'Care Fund', 12000.00, 9000.00, 'Distributed in clinics', 'Ongoing', 'New', 'Online'),
('024', 'Eco-Friendly Clothing', 'Environment', 10.00, 20.00, 600, 12000.00, 300, 'Urban Area N', '2024-02-20', 'William Harris', 'Branch N', 'Sustainable Fashion', 'Green Threads', 15000.00, 10000.00, 'Good sales', 'Ongoing', 'New', 'Direct'),
('025', 'Educational Toys', 'Education', 5.00, 10.00, 1000, 10000.00, 500, 'Rural Area O', '2024-03-05', 'Sophia Lewis', 'Branch O', 'Play and Learn', 'EduToys', 8000.00, 6000.00, 'Distributed in schools', 'Completed', 'New', 'Direct'),
('026', 'Water Purifiers', 'Health', 20.00, 40.00, 300, 12000.00, 150, 'Rural Area P', '2024-04-10', 'Ethan Walker', 'Branch P', 'Clean Water for All', 'WaterCare', 25000.00, 20000.00, 'Installation ongoing', 'Ongoing', 'New', 'Direct'),
('027', 'Eco-Friendly Shoes', 'Environment', 8.00, 15.00, 700, 10500.00, 350, 'Urban Area Q', '2024-05-15', 'Ava Hall', 'Branch Q', 'Walk Green', 'EcoSteps', 12000.00, 9000.00, 'Good response', 'Ongoing', 'New', 'Online'),
('028', 'Sanitary Pads', 'Health', 3.00, 6.00, 1500, 9000.00, 750, 'Rural Area R', '2024-06-20', 'Noah Young', 'Branch R', 'Health for Women', 'WomenCare', 10000.00, 7000.00, 'Distributed in villages', 'Completed', 'New', 'Direct'),
('029', 'Mosquito Nets', 'Health', 6.00, 12.00, 1200, 14400.00, 600, 'Rayagada', '2023-11-10', 'Subhashree Mishra', 'Swasthya Odisha', 'Malaria Prevention', 'Health First', 15000.00, 12000.00, 'Distributed in villages', 'Completed', 'New', 'Direct'),
('030', 'Solar Chargers', 'Energy', 15.00, 30.00, 400, 12000.00, 200, 'Nuapada', '2023-12-01', 'Biswajit Sahoo', 'Utkal Jyoti', 'Solar Power for All', 'Sun Energy', 10000.00, 8000.00, 'Installation ongoing', 'Ongoing', 'Refurbished', 'Direct'),
('031', 'First Aid Kits', 'Health', 7.00, 15.00, 800, 12000.00, 400, 'Malkangiri', '2024-01-15', 'Rohit Pradhan', 'Swasthya Seva', 'Emergency Medical Aid', 'Care Fund', 12000.00, 9000.00, 'Distributed in clinics', 'Ongoing', 'New', 'Online'),
('032', 'Eco-Friendly Clothing', 'Environment', 10.00, 20.00, 600, 12000.00, 300, 'Dhenkanal', '2024-02-20', 'Tanushree Nayak', 'Green Odisha', 'Sustainable Fashion', 'Eco Threads', 15000.00, 10000.00, 'Good sales', 'Ongoing', 'New', 'Direct'),
('033', 'Educational Toys', 'Education', 5.00, 10.00, 1000, 10000.00, 500, 'Nabarangpur', '2024-03-05', 'Satya Ranjan Behera', 'Shiksha Odisha', 'Play and Learn', 'EduToys', 8000.00, 6000.00, 'Distributed in schools', 'Completed', 'New', 'Direct');
SELECT *FROM ngo_product_sales;
